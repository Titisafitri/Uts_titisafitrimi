package com.uts_titisafitriloopj

data class Course(
    val title : String,
    val path : String,
    val image : String
)
